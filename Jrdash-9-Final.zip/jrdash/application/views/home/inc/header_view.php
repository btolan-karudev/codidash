<!doctype html>
<html lang="en">
<head>
    <title>jrDash</title>
    <link rel="stylesheet" href="<?=base_url()?>public/third-party/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?=base_url()?>public/css/style.css" />
    
    <script src="<?=base_url()?>public/third-party/js/jquery.js"></script>
    <script src="<?=base_url()?>public/third-party/js/bootstrap.js"></script>
    
</head>
<body>
        
<header>
    jrDash
</header>

<!-- start:wrapper -->
<div class="wrapper">